package com.clases;

import java.util.ArrayList;
import java.util.Random;

public class Deck {

    private ArrayList<Card> cards;

    // Constructor con el cual se inicializa el mazo de cartas
    public Deck() {
        cards = new ArrayList<Card>();

        // Recorremos los 4 palos de cartas (Corazon, Diamantes, Picas y Trevoles)
        for (short a=0; a<=3; a++)
        {
            // Con esta linea se elije el color Rojo = 0, Nego = 1
            short c = a <= 1 ? (short) 0: (short) 1;
            // Recorremos las 12 cartas de cada palo
            for (short b=0; b<=12; b++)
            {
                //agregamos la carta
                cards.add( new Card(Card.palos[a], Card.valores[b], Card.colores[c]) );
            }
        }
    }
    public void Shuffle() {

        int index_1, index_2;
        Random generator = new Random();
        Card temp;

        //Tomamos el total de cartas
        int size = cards.size() - 1;

        //Se realiza una mezcla de las cartas de 100 veces
        for (short i=0; i<100; i++)
        {
            // Se toman dos indices al azar
            index_1 = generator.nextInt( size );
            index_2 = generator.nextInt( size );

            // Se toma la carta con el indice index_2
            temp = (Card) cards.get( index_2 );

            // Se remplaza la carta con el indice index_2 por la carta con el indice index_1
            cards.set( index_2 , cards.get( index_1 ) );

            // Se remplaza la carta con el indice index_1 por la carta con el indice index_2
            cards.set( index_1, temp );
        }

        System.out.println("Se mezcló el Deck.");
    }

    public void Head() {
        // Se toma una carta del mazo y se elimina
        Card CardHead = cards.remove(0);

        // Se imprime la carta tomada
        System.out.println( CardHead.getPalo() + ", " + CardHead.getColor() +", " + CardHead.getValor());

        // Se imprime cuantas cartas quedan.
        System.out.println("Quedan [" + TotalCards() + "] Cartas");
    }

    public void Pick() {
        Random generator = new Random();

        // Se toma una carta al azar y se elimina del mazo
        Card CarPick = cards.remove(generator.nextInt(cards.size() -1) );

        // Se imprime la carta que se tomo al azar
        System.out.println(CarPick.getPalo() + ", " + CarPick.getColor() +", " + CarPick.getValor());

        // Se imprime cuantas cartas quedan
        System.out.println("Quedan [" + TotalCards() + "] Cartas");
    }

    public void Hand() {
        Random generator = new Random();

        //Se realiza un recorrido para tomar 5 cartas al azar del mazo
        for(int i = 0; i <= 4; i++) {
            //Se toma una carta del mazo y se elimina
            Card CardHand = cards.remove(generator.nextInt(cards.size() -1) );

            //Se imprime la carta tomada.
            System.out.println(CardHand.getPalo() + ", " + CardHand.getColor() +", " + CardHand.getValor());
        }

        // Se imprime cuantas cartas quedan
        System.out.println("Quedan [" + TotalCards() + "] Cartas");
    }


    public int TotalCards() {
        // Se regresa el total de cartas
        return cards.size();
    }

    public void Imprimir()
    {
        //Se imprimen todas las cartas.
        for(Card card: cards)
        {
            System.out.println( card.getPalo() + ", " + card.getColor() +", " + card.getValor() );
        }
    }

}
