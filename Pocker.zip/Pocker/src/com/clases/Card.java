package com.clases;

public class Card {
    private String valor, palo, color;

    //Se inicializan las variables con los valores solicitados
    public static String[] palos = { "tréboles", "corazones", "picas", "diamantes" };
    public static String[] colores = { "rojo", "negro" };
    public static String[] valores = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "A", "J", "Q", "K" };

    //Constructor para crear las cartas
    Card(String palo, String valor, String color)
    {
        this.valor = valor;
        this.palo = palo;
        this.color = color;
    }

    public String getValor() {
        return valor;
    }

    public String getPalo() {
        return palo;
    }

    public String getColor() {
        return color;
    }
}
