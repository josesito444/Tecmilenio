package com.principal;

import com.clases.Deck;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        //Se crea la variable para escuchar cuando de teclea algo
        Scanner entradaEscaner = new Scanner(System.in);
        // Instancia de la clase Deck
        Deck deck = new Deck();

        //Se realiza un ciclo infinito hasta que se elige la opcion de salir
        while(true){

            String opcion;

            //Realizamos la impresion del menu
            System.out.println("Menu poker");
            System.out.println("");
            System.out.println("1.- Shuffle");
            System.out.println("2.- Head");
            System.out.println("3.- Pick");
            System.out.println("4.- Hand");
            System.out.println("0.- Salir");

            // Esperamos hasta que se teclea una letra
            opcion = entradaEscaner.nextLine();

            // Validamos que la opcion seleccionada sea 0 para terminar el proceso
            if(opcion.equals("0")){
                System.out.println("Adios");
                // Con esta instruccion se termina el ciclo WHILE
                break;
            }

            // Evaluamos la opcion seleccionada y ejecutamos la opcion.
            switch (opcion) {
                case "1":
                    System.out.println("");
                    deck.Shuffle();
                    System.out.println("");
                    break;
                case "2":
                    System.out.println("");
                    deck.Head();
                    System.out.println("");
                    break;
                case "3":
                    System.out.println("");
                    deck.Pick();
                    System.out.println("");
                    break;
                case "4":
                    System.out.println("");
                    deck.Hand();
                    System.out.println("");
                    break;
                default: System.out.println("Opcion Incorrecta");
                    break;
            }

            System.out.println("Enter para continuar");
            entradaEscaner.nextLine();
        }
    }
}
