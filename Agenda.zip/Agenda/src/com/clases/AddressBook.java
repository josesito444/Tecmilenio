package com.clases;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AddressBook {

    public HashMap<String,String> Contactos;

    public static void main(String[] args) {

        Scanner entradaEscaner = new Scanner(System.in);
        String Numero, Nombre;
        AddressBook addressBook = new AddressBook();
        addressBook.Load();

        System.out.println("Bienvenido a su agenda");
        System.out.println(" ");
        while(true){
            System.out.println("Seleccione una opcion");
            System.out.println("1.- Listar Contactos");
            System.out.println("2.- Crear Contacto");
            System.out.println("3.- Borrar Contacto");
            System.out.println("0.- Salir");

            System.out.print(" ");
            String Opcion = entradaEscaner.nextLine();

            System.out.println("");

            if(Opcion.equals("0")){ // Si la opcion es 0 se termina el proceso;
                System.out.println("Gracias Bye");
                break;
            }


            switch (Opcion){
                case "1":
                    addressBook.List();
                    entradaEscaner.nextLine();
                    break;
                case "2":
                    System.out.println("Teclee el número");
                    Numero = entradaEscaner.nextLine();

                    System.out.println("Teclee el nombre");
                    Nombre = entradaEscaner.nextLine();

                    addressBook.Create(Numero, Nombre);

                    break;
                case "3":
                    System.out.println("Teclee el número");
                    Numero = entradaEscaner.nextLine();

                    addressBook.Delete(Numero);
                    break;
                default: System.out.println("Opcion incorrecta");
                    break;
            }
            System.out.println("");
            System.out.println("");
        }
    }

    public void Load() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("agenda.csv");

        // Se inicializa el HashMap
        Contactos = new HashMap<String,String>();

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    //Se agrega el contacto al HashMap
                    Contactos.put(attributes[0], attributes[1]);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }

    public void Save()
    {

        // Se crea la variable para escribir en el archivo csv
        try (PrintWriter writer = new PrintWriter(new File("agenda.csv"))) {

            // Se crea la instancia de StringBuilder para ecribir en el archivo
            StringBuilder sb = new StringBuilder();

            //Se recorre el HasHMap para escribir los nuevos cambios
            for(Map.Entry<String, String> contacto: Contactos.entrySet()){

                // Se agregan los datos el Key corresponde al numero, el Value corresponde al nombre \n es para dar un salto
                //de linea dentro del archivo
                sb.append(contacto.getKey());
                sb.append(',');
                sb.append(contacto.getValue());
                sb.append('\n');
            }

            //Se escribe en el archivo los nuevos cambios en la agenda
            writer.write(sb.toString());
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }

    public void List()
    {
        //Se recorre la variable HashMao para obtener todos los contactos
        System.out.println("Contactos: ");
        for(Map.Entry<String, String> contacto: Contactos.entrySet()){
            System.out.println(contacto.getKey() + ": " + contacto.getValue());
        }
    }

    public void Create(String Telefono, String Nombre)
    {
        // Se inserta el nuevo numero capturado
        Contactos.put(Telefono, Nombre);
        // Se manda grbar en el archivo
        Save();
    }

    public void Delete(String Telefono)
    {
        // Se elimina el numero
        Contactos.remove(Telefono);
        //Se manda grabar los nuevos cambios en el archivo
        Save();
    }
}
