package com.SacarPromedios;

public class Promedios {
    public static void main(String[] args) {

        SacarPromedios prom = new SacarPromedios();

        int promedio = prom.promedioCalificaciones(prom.Calificacioness);
        String Calificacion = prom.CalificacionFinal(promedio);

        prom.ImprimirCalificaciones(prom.NombreEstudiante, promedio, Calificacion);
    }
}
