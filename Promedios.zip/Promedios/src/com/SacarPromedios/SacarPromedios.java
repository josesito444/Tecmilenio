package com.SacarPromedios;

public class SacarPromedios {
    public String NombreEstudiante = "Nombre de estudiante";
    public int Calificacioness[] = { 60, 90, 90, 90, 90 };

    public int promedioCalificaciones(int Calificaciones[]){
        int promedio = 0;
        int suma = 0;

        for(int i = 0; i <= Calificaciones.length -1; i++)
        {
            suma += Calificaciones[i];
        }
        promedio = suma / Calificaciones.length;
        return promedio;
    }

    public String CalificacionFinal(int Promedio)
    {
        String Calificacion = "E";

        if(Promedio <= 50)
            return "F";
        if(Promedio >= 51 && Promedio <= 60)
            return "E";

        if(Promedio >= 61 && Promedio <= 70)
            return "D";

        if(Promedio >= 71 && Promedio <= 80)
            return "C";

        if(Promedio >= 81 && Promedio <= 90)
            return "B";

        if(Promedio >= 91 && Promedio <= 100)
            return "A";

        return  Calificacion;
    }

    public void ImprimirCalificaciones(String Nombre, int Promedio, String Calificacion)
    {
        System.out.println("Nombre del estudiante: " + NombreEstudiante);

        for(int i = 0; i <= Calificacioness.length - 1;i++)
        {
            System.out.println("Calification " + (i+1) + ": " + Calificacioness[i] );
        }

        System.out.println("Promedio: " + Promedio);
        System.out.println("Calificacion: " + Calificacion);
    }
}
