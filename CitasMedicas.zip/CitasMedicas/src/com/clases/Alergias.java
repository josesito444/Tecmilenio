package com.clases;

public class Alergias {
    private int AlergiaID;
    private String Nombre;
    private String Descripcion;

    public int getAlergiaID() {
        return AlergiaID;
    }
    public void setAlergiaID(int AlergiaID) {
        this.AlergiaID = AlergiaID;
    }

    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }
    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String toString(){
        return Nombre;
    }
}
