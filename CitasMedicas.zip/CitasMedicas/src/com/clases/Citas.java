package com.clases;

public class Citas {
    private int CitaID;
    private String FechaHora;
    private String MotivoCita;
    private int PacienteID;
    private int DoctorID;

    public int getCitaID() {
        return CitaID;
    }
    public void setCitaID(int CitaID) {
        this.CitaID = CitaID;
    }

    public String getFechaHora() {
        return FechaHora;
    }
    public void setFechaHora(String FechaHora) {
        this.FechaHora = FechaHora;
    }

    public String getMotivoCita() {
        return MotivoCita;
    }
    public void setMotivoCita(String MotivoCita) {
        this.MotivoCita = MotivoCita;
    }

    public int getPacienteID() {
        return PacienteID;
    }
    public void setPacienteID(int PacienteID) {
        this.PacienteID = PacienteID;
    }

    public int getDoctorID() {
        return DoctorID;
    }
    public void setDoctorID(int DoctorID) {
        this.DoctorID = DoctorID;
    }
}
