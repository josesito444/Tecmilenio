package com.clases;

public class Doctores {
    private int DoctorID;
    private String Nombre;
    private String ApPaterno;
    private String ApMaterno;
    private int EspecialidadID;

    public int getDoctorID() {
        return DoctorID;
    }
    public void setDoctorID(int DoctorID) {
        this.DoctorID = DoctorID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApPaterno() {
        return ApPaterno;
    }

    public void setApPaterno(String ApPaterno) {
        this.ApPaterno = ApPaterno;
    }

    public String getApMaterno() {
        return ApMaterno;
    }

    public void setApMaterno(String ApMaterno) {
        this.ApMaterno = ApMaterno;
    }

    public int getEspecialidadID() {
        return EspecialidadID;
    }

    public void setEspecialidadID(int EspecialidadID) {
        this.EspecialidadID = EspecialidadID;
    }

    public String toString(){
        return Nombre + " " + ApPaterno + " " + ApMaterno;
    }
}
