package com.clases;

public class RolUsuarios {
    private int RolUsuarioID;
    private String NombreRol;

    public int getRolUsuarioID() {
        return RolUsuarioID;
    }
    public void setRolUsuarioID(int RolUsuarioID) {
        this.RolUsuarioID = RolUsuarioID;
    }

    public String getNombreRol() {
        return NombreRol;
    }
    public void setNombreRol(String NombreRol) {
        this.NombreRol = NombreRol;
    }

    @Override
    public String toString(){
        return NombreRol;
    }
}
