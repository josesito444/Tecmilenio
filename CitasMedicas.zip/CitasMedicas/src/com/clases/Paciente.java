package com.clases;

public class Paciente {
    private int PacienteID;
    private String Nombre;
    private String ApPaterno;
    private String ApMaterno;
    private int AlergiaID;

    public int getPacienteID() {
        return PacienteID;
    }
    public void setPacienteID(int PacienteID) {
        this.PacienteID = PacienteID;
    }

    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getAlergiaID() {
        return AlergiaID;
    }
    public void setAlergiaID(int AlergiaID) {
        this.AlergiaID = AlergiaID;
    }

    public String getApPaterno() {
        return ApPaterno;
    }
    public void setApPaterno(String ApPaterno) {
        this.ApPaterno = ApPaterno;
    }

    public String getApMaterno() {
        return ApMaterno;
    }
    public void setApMaterno(String ApMaterno) {
        this.ApMaterno = ApMaterno;
    }

    public String toString() {
        return Nombre + " " + ApPaterno + " " + ApMaterno;
    }
}
