package com.clases;

public class Especialidad {
    private int EspecialidadID;
    private String Nombre;
    private String Descripcion;

    public int getEspecialidadID() {
        return EspecialidadID;
    }
    public void setEspecialidadID(int EspecialidadID) {
        this.EspecialidadID = EspecialidadID;
    }

    public String getDescripcion() {
        return Descripcion;
    }
    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String toString(){
        return Nombre;
    }
}
