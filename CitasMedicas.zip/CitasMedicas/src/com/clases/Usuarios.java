package com.clases;

public class Usuarios {
    private int UsuarioID;
    private String UserName;
    private String Contrasenia;
    private int RolUsuarioID;

    public int getUsuarioID() {
        return UsuarioID;
    }
    public void setUsuarioID(int UsuarioID) {
        this.UsuarioID = UsuarioID;
    }

    public String getUserName() {
        return UserName;
    }
    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getContrasenia() {
        return Contrasenia;
    }
    public void setContrasenia(String Contrasenia) {
        this.Contrasenia = Contrasenia;
    }

    public int getRolUsuarioID() {
        return RolUsuarioID;
    }
    public void setRolUsuarioID(int RolUsuarioID) {
        this.RolUsuarioID = RolUsuarioID;
    }
}
