package com.dboperaciones;

import com.clases.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class DBOperaciones {
    public boolean GuardarCita(Citas CitaNueva) throws FileNotFoundException{

        ArrayList<Citas> ListCitas = CargarCitas();
        StringBuilder sb;

        try (PrintWriter writer = new PrintWriter(new File("Citas.csv"))) {

            for(Citas cita: ListCitas){
                sb = new StringBuilder();
                sb.append(cita.getCitaID());
                sb.append(',');
                sb.append(cita.getFechaHora());
                sb.append(',');
                sb.append(cita.getMotivoCita());
                sb.append(',');
                sb.append(cita.getPacienteID());
                sb.append(',');
                sb.append(cita.getDoctorID());
                sb.append('\n');
                writer.write(sb.toString());
            }

            sb = new StringBuilder();
            sb.append(CitaNueva.getCitaID());
            sb.append(',');
            sb.append(CitaNueva.getFechaHora());
            sb.append(',');
            sb.append(CitaNueva.getMotivoCita());
            sb.append(',');
            sb.append(CitaNueva.getPacienteID());
            sb.append(',');
            sb.append(CitaNueva.getDoctorID());
            sb.append('\n');

            writer.write(sb.toString());

            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }

        return false;
    }
    public boolean EliminarCita(Citas CitaEliminar){

        ArrayList<Citas> ListCitas = CargarCitas();

        try (PrintWriter writer = new PrintWriter(new File("Citas.csv"))) {


            ListCitas.stream().filter((cita) -> (cita.getCitaID() != CitaEliminar.getCitaID())).map((cita) -> {
                StringBuilder sb = new StringBuilder();
                sb.append(cita.getCitaID());
                sb.append(',');
                sb.append(cita.getFechaHora());
                sb.append(',');
                sb.append(cita.getMotivoCita());
                sb.append(',');
                sb.append(cita.getPacienteID());
                sb.append(',');
                sb.append(cita.getDoctorID());
                return sb;
            }).map((sb) -> {
                sb.append('\n');
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });

            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    public boolean ActualizarCita(Citas CitaActualizar){
        ArrayList<Citas> ListCitas = CargarCitas();
        boolean regresa= false;
        try (PrintWriter writer = new PrintWriter(new File("Citas.csv"))) {

            ListCitas.stream().map((cita) -> {
                StringBuilder sb = new StringBuilder();
                if(cita.getCitaID() == CitaActualizar.getCitaID()){
                    sb.append(CitaActualizar.getCitaID());
                    sb.append(',');
                    sb.append(CitaActualizar.getFechaHora());
                    sb.append(',');
                    sb.append(CitaActualizar.getMotivoCita());
                    sb.append(',');
                    sb.append(CitaActualizar.getPacienteID());
                    sb.append(',');
                    sb.append(CitaActualizar.getDoctorID());
                    sb.append('\n');
                }
                else {
                    sb.append(cita.getCitaID());
                    sb.append(',');
                    sb.append(cita.getFechaHora());
                    sb.append(',');
                    sb.append(cita.getMotivoCita());
                    sb.append(',');
                    sb.append(cita.getPacienteID());
                    sb.append(',');
                    sb.append(cita.getDoctorID());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });

            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return regresa;
    }
    public ArrayList<Citas> CargarCitas() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Citas.csv");

        ArrayList<Citas> ListCitas = new ArrayList<>();
        Citas Cita;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    Cita = new Citas();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    Cita.setCitaID(Integer.parseInt(attributes[0]));
                    Cita.setFechaHora(attributes[1]);
                    Cita.setMotivoCita(attributes[2]);
                    Cita.setPacienteID(Integer.parseInt(attributes[3]));
                    Cita.setDoctorID(Integer.parseInt(attributes[4]));

                    ListCitas.add(Cita);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListCitas;
    }
    public Citas CargarCitaByID(int CitasID){
        ArrayList<Citas> ListCitas = CargarCitas();
        Citas citas = new Citas();

        for(Citas cit: ListCitas){
            if(cit.getCitaID() == CitasID){
                return cit;
            }
        }
        citas.setCitaID(0);
        return citas;
    }

    public boolean GuardarDoctores(Doctores DoctorNuevo) {

        ArrayList<Doctores> ListDoctores = CargarDoctores();
        StringBuilder sb;

        try (PrintWriter writer = new PrintWriter(new File("Doctores.csv"))) {

            for(Doctores doctor: ListDoctores){
                sb = new StringBuilder();

                sb.append(doctor.getDoctorID());
                sb.append(',');
                sb.append(doctor.getNombre());
                sb.append(',');
                sb.append(doctor.getApPaterno());
                sb.append(',');
                sb.append(doctor.getApMaterno());
                sb.append(',');
                sb.append(doctor.getEspecialidadID());
                sb.append('\n');
                writer.write(sb.toString());
            }


            // Se crea la instancia de StringBuilder para ecribir en el archivo
            sb = new StringBuilder();

            sb.append(DoctorNuevo.getDoctorID());
            sb.append(',');
            sb.append(DoctorNuevo.getNombre());
            sb.append(',');
            sb.append(DoctorNuevo.getApPaterno());
            sb.append(',');
            sb.append(DoctorNuevo.getApMaterno());
            sb.append(',');
            sb.append(DoctorNuevo.getEspecialidadID());
            sb.append('\n');

            //Se escribe en el archivo los nuevos cambios en la agenda
            writer.write(sb.toString());

            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    public void ActualizarDoctores(Doctores DoctorActualizar){

        try (PrintWriter writer = new PrintWriter(new File("Doctores.csv"))) {
            ArrayList<Doctores> ListDoctores = CargarDoctores();

            ListDoctores.stream().map((doctor) -> {
                StringBuilder sb = new StringBuilder();
                if(doctor.getDoctorID()== DoctorActualizar.getDoctorID()){
                    sb.append(DoctorActualizar.getDoctorID());
                    sb.append(',');
                    sb.append(DoctorActualizar.getNombre());
                    sb.append(',');
                    sb.append(DoctorActualizar.getApPaterno());
                    sb.append(',');
                    sb.append(DoctorActualizar.getApMaterno());
                    sb.append(',');
                    sb.append(DoctorActualizar.getEspecialidadID());
                    sb.append('\n');
                }
                else {
                    sb.append(doctor.getDoctorID());
                    sb.append(',');
                    sb.append(doctor.getNombre());
                    sb.append(',');
                    sb.append(doctor.getApPaterno());
                    sb.append(',');
                    sb.append(doctor.getApMaterno());
                    sb.append(',');
                    sb.append(doctor.getEspecialidadID());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public ArrayList<Doctores> CargarDoctores() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Doctores.csv");

        ArrayList<Doctores> ListaDoctores = new ArrayList<>();
        Doctores Doctor;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    Doctor = new Doctores();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    Doctor.setDoctorID(Integer.parseInt(attributes[0]));
                    Doctor.setNombre(attributes[1]);
                    Doctor.setApPaterno(attributes[2]);
                    Doctor.setApMaterno(attributes[3]);
                    Doctor.setEspecialidadID(Integer.parseInt(attributes[4]));

                    ListaDoctores.add(Doctor);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListaDoctores;
    }
    public Doctores CargarDoctorByID(int DoctorID){
        ArrayList<Doctores> ListDoctor = CargarDoctores();
        Doctores doctor = new Doctores();

        for(Doctores doc: ListDoctor){
            if(doc.getDoctorID() == DoctorID){
                return doc;
            }
        }
        doctor.setDoctorID(0);
        return doctor;
    }

    public boolean GuardarPaciente(Paciente PacienteNuevo) throws IOException {

        ArrayList<Paciente> ListPaciente = CargarPaciente();
        StringBuilder sb;

        try (PrintWriter writer = new PrintWriter(new File("Pacientes.csv"))) {

            for(Paciente paciente: ListPaciente){
                sb = new StringBuilder();
                sb.append(paciente.getPacienteID());
                sb.append(',');
                sb.append(paciente.getNombre());
                sb.append(',');
                sb.append(paciente.getApPaterno());
                sb.append(',');
                sb.append(paciente.getApMaterno());
                sb.append(',');
                sb.append(paciente.getAlergiaID());
                sb.append('\n');
                writer.write(sb.toString());
            }


            sb= new StringBuilder();

            sb.append(PacienteNuevo.getPacienteID());
            sb.append(',');
            sb.append(PacienteNuevo.getNombre());
            sb.append(',');
            sb.append(PacienteNuevo.getApPaterno());
            sb.append(',');
            sb.append(PacienteNuevo.getApMaterno());
            sb.append(',');
            sb.append(PacienteNuevo.getAlergiaID());
            sb.append('\n');

            //Se escribe en el archivo los nuevos cambios en la agenda
            writer.write(sb.toString());

            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    public void ActualizarPaciente(Paciente PacienteActualizar){

        try (PrintWriter writer = new PrintWriter(new File("Pacientes.csv"))) {
            ArrayList<Paciente> ListPaciente = CargarPaciente();

            ListPaciente.stream().map((paciente) -> {
                StringBuilder sb = new StringBuilder();
                if(paciente.getPacienteID() == PacienteActualizar.getPacienteID()){
                    sb.append(PacienteActualizar.getPacienteID());
                    sb.append(',');
                    sb.append(PacienteActualizar.getNombre());
                    sb.append(',');
                    sb.append(PacienteActualizar.getApPaterno());
                    sb.append(',');
                    sb.append(PacienteActualizar.getApMaterno());
                    sb.append(',');
                    sb.append(PacienteActualizar.getAlergiaID());
                    sb.append('\n');
                }
                else {
                    sb.append(paciente.getPacienteID());
                    sb.append(',');
                    sb.append(paciente.getNombre());
                    sb.append(',');
                    sb.append(paciente.getApPaterno());
                    sb.append(',');
                    sb.append(paciente.getApMaterno());
                    sb.append(',');
                    sb.append(paciente.getAlergiaID());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public ArrayList<Paciente> CargarPaciente() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Pacientes.csv");

        ArrayList<Paciente> ListaPaciente = new ArrayList<>();
        Paciente Pacien;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    Pacien = new Paciente();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    Pacien.setPacienteID(Integer.parseInt(attributes[0]));
                    Pacien.setNombre(attributes[1]);
                    Pacien.setApPaterno(attributes[2]);
                    Pacien.setApMaterno(attributes[3]);
                    Pacien.setAlergiaID(Integer.parseInt(attributes[4]));

                    ListaPaciente.add(Pacien);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListaPaciente;
    }
    public Paciente CargarPacienteByID(int PacienteID){
        ArrayList<Paciente> ListPaciente = CargarPaciente();
        Paciente paciente = new Paciente();

        for(Paciente pacie: ListPaciente){
            if(pacie.getPacienteID() == PacienteID){
                return pacie;
            }
        }
        paciente.setPacienteID(0);
        return paciente;
    }

    public boolean GuardarUsuario(Usuarios UsuarioNuevo) {
        boolean grabado = false;
        ArrayList<Usuarios> ListUsuarios = CargarUsuarios();
        StringBuilder sb;
        try (PrintWriter writer = new PrintWriter(new File("Usuarios.csv"))) {

            for(Usuarios usuario: ListUsuarios){
                sb = new StringBuilder();

                sb.append(usuario.getUsuarioID());
                sb.append(',');
                sb.append(usuario.getUserName());
                sb.append(',');
                sb.append(usuario.getContrasenia());
                sb.append(',');
                sb.append(usuario.getRolUsuarioID());
                sb.append('\n');
                writer.write(sb.toString());
            }

            sb = new StringBuilder();
            sb.append(UsuarioNuevo.getUsuarioID());
            sb.append(',');
            sb.append(UsuarioNuevo.getUserName());
            sb.append(',');
            sb.append(UsuarioNuevo.getContrasenia());
            sb.append(',');
            sb.append(UsuarioNuevo.getRolUsuarioID());
            sb.append('\n');

            //Se escribe en el archivo los nuevos cambios en la agenda
            writer.write(sb.toString());

            grabado = true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return grabado;
    }
    public void ActualizarUsuario(Usuarios UsuarioActualizar){

        try (PrintWriter writer = new PrintWriter(new File("Usuarios.csv"))) {
            ArrayList<Usuarios> ListUsuarios = CargarUsuarios();

            ListUsuarios.stream().map((usuario) -> {
                StringBuilder sb = new StringBuilder();
                if(usuario.getUsuarioID() == UsuarioActualizar.getUsuarioID()){
                    sb.append(UsuarioActualizar.getUsuarioID());
                    sb.append(',');
                    sb.append(UsuarioActualizar.getUserName());
                    sb.append(',');
                    sb.append(UsuarioActualizar.getContrasenia());
                    sb.append(',');
                    sb.append(UsuarioActualizar.getRolUsuarioID());
                    sb.append('\n');
                }
                else {
                    sb.append(usuario.getUsuarioID());
                    sb.append(',');
                    sb.append(usuario.getUserName());
                    sb.append(',');
                    sb.append(usuario.getContrasenia());
                    sb.append(',');
                    sb.append(usuario.getRolUsuarioID());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public ArrayList<Usuarios> CargarUsuarios() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Usuarios.csv");

        ArrayList<Usuarios> ListaUsuarios = new ArrayList<>();
        Usuarios usuario;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    usuario = new Usuarios();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    usuario.setUsuarioID(Integer.parseInt(attributes[0]));
                    usuario.setUserName(attributes[1]);
                    usuario.setContrasenia(attributes[2]);
                    usuario.setRolUsuarioID(Integer.parseInt(attributes[3]));

                    ListaUsuarios.add(usuario);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListaUsuarios;
    }

    public void GuardarRolUsuario(RolUsuarios RolUsuarioNuevo) {
        try (PrintWriter writer = new PrintWriter(new File("Roles.csv"))) {

            // Se crea la instancia de StringBuilder para ecribir en el archivo
            StringBuilder sb = new StringBuilder();

            sb.append(RolUsuarioNuevo.getRolUsuarioID());
            sb.append(',');
            sb.append(RolUsuarioNuevo.getNombreRol());
            sb.append('\n');

            //Se escribe en el archivo los nuevos cambios en la agenda
            writer.write(sb.toString());
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public void ActualizarRolUsuario(RolUsuarios RolUsuarioActualizar){

        try (PrintWriter writer = new PrintWriter(new File("Roles.csv"))) {
            ArrayList<RolUsuarios> ListRolUsuarios = CargarRolUsuarios();

            ListRolUsuarios.stream().map((rolUsuario) -> {
                StringBuilder sb = new StringBuilder();
                if(rolUsuario.getRolUsuarioID() == RolUsuarioActualizar.getRolUsuarioID()){
                    sb.append(RolUsuarioActualizar.getRolUsuarioID());
                    sb.append(',');
                    sb.append(RolUsuarioActualizar.getNombreRol());
                    sb.append('\n');
                }
                else {
                    sb.append(rolUsuario.getRolUsuarioID());
                    sb.append(',');
                    sb.append(rolUsuario.getNombreRol());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public ArrayList<RolUsuarios> CargarRolUsuarios() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Roles.csv");

        ArrayList<RolUsuarios> ListaRolUsuarios = new ArrayList<>();
        RolUsuarios rolUsuario;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    rolUsuario = new RolUsuarios();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    rolUsuario.setRolUsuarioID(Integer.parseInt(attributes[0]));
                    rolUsuario.setNombreRol(attributes[1]);

                    ListaRolUsuarios.add(rolUsuario);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListaRolUsuarios;
    }

    public boolean GuardarEspecialidad(Especialidad EspecialidadNuevo) {

        ArrayList<Especialidad> ListEspecialidad = CargarEspecialidades();
        StringBuilder sb;

        try (PrintWriter writer = new PrintWriter(new File("Especialidades.csv"))) {

            for(Especialidad especialidad: ListEspecialidad){
                sb = new StringBuilder();
                sb.append(especialidad.getEspecialidadID());
                sb.append(',');
                sb.append(especialidad.getNombre());
                sb.append(',');
                sb.append(especialidad.getDescripcion());
                sb.append('\n');

                writer.write(sb.toString());
            }

            sb = new StringBuilder();
            sb.append(EspecialidadNuevo.getEspecialidadID());
            sb.append(',');
            sb.append(EspecialidadNuevo.getNombre());
            sb.append(',');
            sb.append(EspecialidadNuevo.getDescripcion());
            sb.append('\n');

            //Se escribe en el archivo los nuevos cambios en la agenda
            writer.write(sb.toString());

            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    public void ActualizarEspecialidad(Especialidad EspecialidadActualizar){

        ArrayList<Especialidad> ListEspecialidad =CargarEspecialidades();

        try (PrintWriter writer = new PrintWriter(new File("Especialidades.csv"))) {

            ListEspecialidad.stream().map((especialidad) -> {
                StringBuilder sb = new StringBuilder();
                if(especialidad.getEspecialidadID() == EspecialidadActualizar.getEspecialidadID()){
                    sb.append(EspecialidadActualizar.getEspecialidadID());
                    sb.append(',');
                    sb.append(EspecialidadActualizar.getNombre());
                    sb.append(',');
                    sb.append(EspecialidadActualizar.getDescripcion());
                    sb.append('\n');
                }
                else {
                    sb.append(especialidad.getEspecialidadID());
                    sb.append(',');
                    sb.append(especialidad.getNombre());
                    sb.append(',');
                    sb.append(especialidad.getDescripcion());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public ArrayList<Especialidad> CargarEspecialidades() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Especialidades.csv");

        ArrayList<Especialidad> ListaEspecialidades = new ArrayList<>();
        Especialidad especialidad;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    especialidad = new Especialidad();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    especialidad.setEspecialidadID(Integer.parseInt(attributes[0]));
                    especialidad.setNombre(attributes[1]);
                    especialidad.setDescripcion(attributes[2]);

                    ListaEspecialidades.add(especialidad);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListaEspecialidades;
    }

    public boolean GuardarAlergias(Alergias AlergiaNuevo) {

        StringBuilder sb;
        ArrayList<Alergias> ListAlergias = CargarAlergias();

        try (PrintWriter writer = new PrintWriter(new File("Alergias.csv"))) {

            for(Alergias alergia: ListAlergias) {

                sb = new StringBuilder();
                sb.append(alergia.getAlergiaID());
                sb.append(',');
                sb.append(alergia.getNombre());
                sb.append(',');
                sb.append(alergia.getDescripcion());
                sb.append('\n');

                writer.write(sb.toString());
            }

            sb = new StringBuilder();
            sb.append(AlergiaNuevo.getAlergiaID());
            sb.append(',');
            sb.append(AlergiaNuevo.getNombre());
            sb.append(',');
            sb.append(AlergiaNuevo.getDescripcion());
            sb.append('\n');

            writer.write(sb.toString());
            return true;
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
    public void ActualizarAlergias(Alergias AlergiaActualizar){

        ArrayList<Alergias> ListAlergias = CargarAlergias();

        try (PrintWriter writer = new PrintWriter(new File("Alergias.csv"))) {

            ListAlergias.stream().map((alergia) -> {
                StringBuilder sb = new StringBuilder();
                if(alergia.getAlergiaID() == AlergiaActualizar.getAlergiaID()){
                    sb.append(AlergiaActualizar.getAlergiaID());
                    sb.append(',');
                    sb.append(AlergiaActualizar.getNombre());
                    sb.append(',');
                    sb.append(AlergiaActualizar.getDescripcion());
                    sb.append('\n');
                }
                else {
                    sb.append(alergia.getAlergiaID());
                    sb.append(',');
                    sb.append(alergia.getNombre());
                    sb.append(',');
                    sb.append(alergia.getDescripcion());
                    sb.append('\n');
                }
                return sb;
            }).forEachOrdered((sb) -> {
                writer.write(sb.toString());
            });
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
    public ArrayList<Alergias> CargarAlergias() {
        // Se obtiene la ruta del archivo
        Path pathToFile = Paths.get("Alergias.csv");

        ArrayList<Alergias> ListaAlergias = new ArrayList<>();
        Alergias alergia;

        // Se obtiene la informacion del archivo
        File f = new File(pathToFile.toString());

        // Evaluamos que exista el archivo.
        if(f.exists()) {

            // Obtenemos el contenido del archivo
            try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {

                // Se obtiene la primeralinea
                String line = br.readLine();

                // Mientras la linea no sea null
                while (line != null) {

                    alergia = new Alergias();
                    // Se divide la line en una arreglo
                    String[] attributes = line.split(",");

                    alergia.setAlergiaID(Integer.parseInt(attributes[0]));
                    alergia.setNombre(attributes[1]);
                    alergia.setDescripcion(attributes[2]);

                    ListaAlergias.add(alergia);

                    // Se lee la siguiente linea.
                    line = br.readLine();
                }
            } catch (IOException ioe) {
            }
        }

        return ListaAlergias;
    }
}
