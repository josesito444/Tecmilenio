package com.vistas;

import com.clases.Alergias;
import com.clases.Paciente;
import com.dboperaciones.DBOperaciones;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class frmPaciente extends javax.swing.JFrame {
    DBOperaciones _context;
    Object _formulario;
    public frmPaciente(Object Formulario) {
        initComponents();
        _context = new DBOperaciones();
        ComboAlergias();
        _formulario = Formulario;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmPaciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmPaciente(0).setVisible(true);
            }
        });
    }

    private void lblAddAlergiaMouseEntered(java.awt.event.MouseEvent evt) {
        Border border = BorderFactory.createMatteBorder(2, 2, 2, 2, Color.BLUE);
        lblAddAlergia.setBorder(border);
    }

    private void lblAddAlergiaMouseExited(java.awt.event.MouseEvent evt) {
        lblAddAlergia.setBorder(null);
    }

    private void lblAddAlergiaMouseClicked(java.awt.event.MouseEvent evt) {
        //this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmAlergias frm = new frmAlergias(_formulario);
        frm.setVisible(true);
    }

    private void btnRegistrarPacienteMouseClicked(java.awt.event.MouseEvent evt) {
        if(ValidarCampos()){

            try {
                ArrayList<Paciente> ListPaciente = _context.CargarPaciente();
                int PacienteID = 0;
                for(Paciente paciente: ListPaciente){
                    if(PacienteID <= paciente.getPacienteID()) {
                        PacienteID = paciente.getPacienteID();
                    }
                }
                PacienteID = PacienteID + 1;


                Alergias alergia = (Alergias) cmbAlergias.getSelectedItem();

                Paciente paciente = new Paciente();
                paciente.setPacienteID(PacienteID);
                paciente.setNombre(txtNombre.getText());
                paciente.setApPaterno(txtApPaterno.getText());
                paciente.setApMaterno(txtApMaterno.getText());
                paciente.setAlergiaID(alergia.getAlergiaID());


                if(_context.GuardarPaciente(paciente)){
                    JOptionPane.showMessageDialog(this, "Paciente Registrado Correctamente");

                    this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                    dispose();
                    frmCitas frm = new frmCitas(_formulario);
                    frm.setVisible(true);
                }
            } catch (IOException ex) {
                Logger.getLogger(frmPaciente.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmCitas frm = new frmCitas(_formulario);
        frm.setVisible(true);
    }

    public void ComboAlergias(){
        ArrayList<Alergias> ListAlergias = _context.CargarAlergias();

        ListAlergias.forEach((alergia) -> {
            cmbAlergias.addItem(alergia);
        });
    }

    public boolean ValidarCampos(){
        boolean continuar = true;
        Border border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red);

        if( txtNombre.getText().equals("") ){
            txtNombre.setBorder(border);
            return false;
        } else {
            txtNombre.setBorder(null);
        }

        if( txtApPaterno.getText().equals("") ){
            txtApPaterno.setBorder(border);
            return false;
        } else {
            txtApPaterno.setBorder(null);
        }

        if( txtApMaterno.getText().equals("") ){
            txtApMaterno.setBorder(border);
            return false;
        } else {
            txtApMaterno.setBorder(null);
        }

        return continuar;
    }

    private javax.swing.JButton btnRegistrarPaciente;
    private javax.swing.JComboBox<Alergias> cmbAlergias;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblAddAlergia;
    private javax.swing.JLabel lblAlergias;
    private javax.swing.JLabel lblApMaterno;
    private javax.swing.JLabel lblApPaterno;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTextField txtApMaterno;
    private javax.swing.JTextField txtApPaterno;
    private javax.swing.JTextField txtNombre;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblApPaterno = new javax.swing.JLabel();
        lblApMaterno = new javax.swing.JLabel();
        lblAlergias = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApPaterno = new javax.swing.JTextField();
        txtApMaterno = new javax.swing.JTextField();
        cmbAlergias = new javax.swing.JComboBox<>();
        lblAddAlergia = new javax.swing.JLabel();
        btnRegistrarPaciente = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 3, 207));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Registro de pacientes");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2)
                                .addGap(39, 39, 39))
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblNombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNombre.setText("Nombre");

        lblApPaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblApPaterno.setText("Apellido Paterno");

        lblApMaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblApMaterno.setText("Apellido Materno");

        lblAlergias.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblAlergias.setText("Alergia");

        txtNombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        txtApPaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        txtApMaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        cmbAlergias.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        lblAddAlergia.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblAddAlergia.setText(" +");
        lblAddAlergia.setToolTipText("Agregar Alergia");
        lblAddAlergia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAddAlergia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAddAlergiaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAddAlergiaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAddAlergiaMouseExited(evt);
            }
        });

        btnRegistrarPaciente.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnRegistrarPaciente.setText("Registrar");
        btnRegistrarPaciente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistrarPacienteMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(lblApPaterno)
                                                        .addComponent(lblApMaterno))
                                                .addGap(11, 11, 11)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(txtApPaterno, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                                                        .addComponent(txtApMaterno)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblNombre)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(btnRegistrarPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(lblAlergias)
                                                                .addGap(37, 37, 37)
                                                                .addComponent(cmbAlergias, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAddAlergia, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblNombre)
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblApPaterno)
                                        .addComponent(txtApPaterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblApMaterno)
                                        .addComponent(txtApMaterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblAlergias)
                                        .addComponent(cmbAlergias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblAddAlergia))
                                .addGap(18, 18, 18)
                                .addComponent(btnRegistrarPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(57, Short.MAX_VALUE))
        );

        setBounds(0, 0, 380, 394);
    }// </editor-fold>
}
