package com.vistas;

import com.clases.Doctores;
import com.clases.Especialidad;
import com.dboperaciones.DBOperaciones;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;

public class frmDoctor extends javax.swing.JFrame {

    DBOperaciones _context;
    Object _formulario;
    public frmDoctor(Object Formulario) {
        initComponents();
        _context = new DBOperaciones();
        ComboEspecialidades();
        _formulario = Formulario;
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmDoctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmDoctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmDoctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmDoctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmDoctor(0).setVisible(true);
            }
        });
    }

    private void lblAgregarEspecialidadMouseEntered(java.awt.event.MouseEvent evt) {
        Border border = BorderFactory.createMatteBorder(2, 2, 2, 2, Color.BLUE);
        lblAgregarEspecialidad.setBorder(border);
    }

    private void lblAgregarEspecialidadMouseExited(java.awt.event.MouseEvent evt) {
        lblAgregarEspecialidad.setBorder(null);
    }

    private void btnGuardarDoctorMouseClicked(java.awt.event.MouseEvent evt) {
        if(ValidarCampos()){
            ArrayList<Doctores> ListDoctores = _context.CargarDoctores();
            int DoctoreID = 0;
            for(Doctores doctores: ListDoctores){
                if(DoctoreID <= doctores.getDoctorID()) {
                    DoctoreID = doctores.getDoctorID();
                }
            }
            DoctoreID = DoctoreID + 1;
            Especialidad especialidad = (Especialidad) cmbEspecialidad.getSelectedItem();
            Doctores doctor = new Doctores();
            doctor.setDoctorID(DoctoreID);
            doctor.setNombre(txtNombre.getText());
            doctor.setApPaterno(txtApPaterno.getText());
            doctor.setApMaterno(txtApMaterno.getText());
            doctor.setEspecialidadID(especialidad.getEspecialidadID());
            if(_context.GuardarDoctores(doctor)){
                JOptionPane.showMessageDialog(this, "Doctor registrado correctamente");

                this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                dispose();
                frmCitas frm = new frmCitas(_formulario);
                frm.setVisible(true);
            }
        }
    }

    private void lblAgregarEspecialidadMouseClicked(java.awt.event.MouseEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmEspecialidades frm = new frmEspecialidades(_formulario);
        frm.setVisible(true);
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmCitas frm = new frmCitas(_formulario);
        frm.setVisible(true);
    }

    public void ComboEspecialidades(){
        ArrayList<Especialidad> ListEspecialidad = _context.CargarEspecialidades();

        for(Especialidad especialidad: ListEspecialidad){
            cmbEspecialidad.addItem(especialidad);
        }
    }

    public boolean ValidarCampos(){
        boolean continuar = true;
        Border border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red);

        if( txtNombre.getText().equals("") ){
            txtNombre.setBorder(border);
            return false;
        } else {
            txtNombre.setBorder(null);
        }

        if( txtApPaterno.getText().equals("") ){
            txtApPaterno.setBorder(border);
            return false;
        } else {
            txtApPaterno.setBorder(null);
        }

        if( txtApMaterno.getText().equals("") ){
            txtApMaterno.setBorder(border);
            return false;
        } else {
            txtApMaterno.setBorder(null);
        }

        if(cmbEspecialidad.getSelectedItem() == null){
            cmbEspecialidad.setBorder(border);
            return false;
        } else {
            cmbEspecialidad.setBorder(null);
        }

        return continuar;
    }



    private javax.swing.JButton btnGuardarDoctor;
    private javax.swing.JComboBox<Especialidad> cmbEspecialidad;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblAgregarEspecialidad;
    private javax.swing.JLabel lblApMaterno;
    private javax.swing.JLabel lblApPaterno;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTextField txtApMaterno;
    private javax.swing.JTextField txtApPaterno;
    private javax.swing.JTextField txtNombre;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblApPaterno = new javax.swing.JLabel();
        lblApMaterno = new javax.swing.JLabel();
        lblEspecialidad = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApPaterno = new javax.swing.JTextField();
        txtApMaterno = new javax.swing.JTextField();
        cmbEspecialidad = new javax.swing.JComboBox<>();
        btnGuardarDoctor = new javax.swing.JButton();
        lblAgregarEspecialidad = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 3, 207));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Registro de doctores");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel2)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblNombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNombre.setText("Nombre");

        lblApPaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblApPaterno.setText("Apellido Paterno");

        lblApMaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblApMaterno.setText("Apellido Paterno");

        lblEspecialidad.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblEspecialidad.setText("Especialiadad");

        txtNombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        txtApPaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        txtApMaterno.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        cmbEspecialidad.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        btnGuardarDoctor.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGuardarDoctor.setText("Guardar Doctor");
        btnGuardarDoctor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarDoctorMouseClicked(evt);
            }
        });

        lblAgregarEspecialidad.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblAgregarEspecialidad.setText(" +");
        lblAgregarEspecialidad.setToolTipText("Agregar Especialidad");
        lblAgregarEspecialidad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAgregarEspecialidadMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAgregarEspecialidadMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAgregarEspecialidadMouseExited(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(102, 102, 102)
                                                .addComponent(btnGuardarDoctor))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(33, 33, 33)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                .addGroup(layout.createSequentialGroup()
                                                                        .addComponent(lblApMaterno)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtApMaterno))
                                                                .addGroup(layout.createSequentialGroup()
                                                                        .addComponent(lblApPaterno)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtApPaterno, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(layout.createSequentialGroup()
                                                                        .addComponent(lblNombre)
                                                                        .addGap(32, 32, 32)
                                                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(lblEspecialidad)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(cmbEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(lblAgregarEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(24, 24, 24))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblNombre)
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblApPaterno)
                                        .addComponent(txtApPaterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblApMaterno)
                                        .addComponent(txtApMaterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblEspecialidad)
                                        .addComponent(cmbEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblAgregarEspecialidad))
                                .addGap(18, 18, 18)
                                .addComponent(btnGuardarDoctor, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(50, Short.MAX_VALUE))
        );

        setBounds(0, 0, 402, 372);
    }// </editor-fold>
}
