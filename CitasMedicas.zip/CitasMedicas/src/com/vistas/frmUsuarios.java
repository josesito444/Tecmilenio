package com.vistas;

import com.clases.RolUsuarios;
import com.clases.Usuarios;
import com.dboperaciones.DBOperaciones;

import javax.swing.*;
import java.util.ArrayList;

public class frmUsuarios extends javax.swing.JFrame{

    DBOperaciones _Context;
    public frmUsuarios() {
        initComponents();
        _Context = new DBOperaciones();
        llenarRoles();
    }

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmUsuarios().setVisible(true);
            }
        });
    }

    private void btnGuardarUsuarioMouseClicked(java.awt.event.MouseEvent evt) {

        ArrayList<Usuarios> ListUsuarios = _Context.CargarUsuarios();

        int IdUsuario = 0;
        for(Usuarios usuario: ListUsuarios) {
            if(IdUsuario <= usuario.getUsuarioID()){
                IdUsuario = usuario.getUsuarioID();
            }
        }
        IdUsuario = IdUsuario + 1;

        RolUsuarios rol = (RolUsuarios)cmbRolUsuario.getSelectedItem();
        Usuarios usuario = new Usuarios();
        usuario.setUserName(txtUserName.getText());
        usuario.setContrasenia(txtContrasena.getText());
        usuario.setRolUsuarioID(rol.getRolUsuarioID());

        if(_Context.GuardarUsuario(usuario)) {
            JOptionPane.showMessageDialog(this, "Usuario Registrado Correctamente");
            this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            dispose();
            frmLogin frm = new frmLogin();
            frm.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Ocurrio un error al registrar Usuario");
        }
    }

    public void llenarRoles() {

        ArrayList<RolUsuarios> roles = _Context.CargarRolUsuarios();

        if(roles.isEmpty()){
            RolUsuarios newRol = new RolUsuarios();
            newRol.setNombreRol("Administrador");
            newRol.setRolUsuarioID(1);
            _Context.GuardarRolUsuario(newRol);
            roles = _Context.CargarRolUsuarios();
        }

        for(RolUsuarios rolUsuario: roles){
            cmbRolUsuario.addItem(rolUsuario);
        }
    }

    private javax.swing.JButton btnGuardarUsuario;
    private javax.swing.JComboBox<RolUsuarios> cmbRolUsuario;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblContrasena;
    private javax.swing.JLabel lblNombreusuario;
    private javax.swing.JLabel lblRolUsuario;
    private javax.swing.JTextField txtContrasena;
    private javax.swing.JTextField txtUserName;

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnGuardarUsuario = new javax.swing.JButton();
        txtUserName = new javax.swing.JTextField();
        txtContrasena = new javax.swing.JTextField();
        cmbRolUsuario = new javax.swing.JComboBox<>();
        lblNombreusuario = new javax.swing.JLabel();
        lblContrasena = new javax.swing.JLabel();
        lblRolUsuario = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 3, 207));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Registro de usuarios");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(63, 63, 63)
                                .addComponent(jLabel2)
                                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnGuardarUsuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGuardarUsuario.setText("Guardar Usuario");
        btnGuardarUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarUsuarioMouseClicked(evt);
            }
        });

        txtUserName.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        txtContrasena.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        cmbRolUsuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        lblNombreusuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNombreusuario.setText("Nombre de Usuario");

        lblContrasena.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblContrasena.setText("Contraseña");

        lblRolUsuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblRolUsuario.setText("Rol Usuario");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(72, 72, 72)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblNombreusuario)
                                        .addComponent(lblContrasena)
                                        .addComponent(lblRolUsuario))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtUserName)
                                        .addComponent(txtContrasena)
                                        .addComponent(cmbRolUsuario, 0, 140, Short.MAX_VALUE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnGuardarUsuario)
                                .addGap(134, 134, 134))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(53, 53, 53)
                                                .addComponent(lblNombreusuario))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtUserName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtContrasena, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblContrasena))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(cmbRolUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblRolUsuario))
                                .addGap(18, 18, 18)
                                .addComponent(btnGuardarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }
}
