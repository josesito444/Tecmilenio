package com.vistas;

import com.clases.Citas;
import com.dboperaciones.DBOperaciones;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class frmPrincipal extends javax.swing.JFrame {
    DBOperaciones _context;
    public frmPrincipal() {
        initComponents();
        _context = new DBOperaciones();
        obtenerCitas();
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmPrincipal().setVisible(true);
            }
        });
    }

    private void btnAgregarCitaMouseClicked(java.awt.event.MouseEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmCitas frm = new frmCitas(new frmPrincipal());
        frm.setVisible(true);
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmLogin frm = new frmLogin();
        frm.setVisible(true);
    }

    public void obtenerCitas(){

        tlbListaCitas.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tlbListaCitas.getColumnModel().getColumn(0).setPreferredWidth(70);
        tlbListaCitas.getColumnModel().getColumn(1).setPreferredWidth(265);
        tlbListaCitas.getColumnModel().getColumn(2).setPreferredWidth(300);
        tlbListaCitas.getColumnModel().getColumn(3).setPreferredWidth(300);

        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setHorizontalAlignment(JLabel.CENTER);
        tlbListaCitas.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
        tlbListaCitas.getColumnModel().getColumn(1).setCellRenderer(cellRenderer);
        tlbListaCitas.getColumnModel().getColumn(2).setCellRenderer(cellRenderer);
        tlbListaCitas.getColumnModel().getColumn(3).setCellRenderer(cellRenderer);

        tlbListaCitas.getTableHeader().setFont(new Font("BOLD", Font.BOLD, 14));

        DefaultTableModel model = (DefaultTableModel) tlbListaCitas.getModel();
        //Object[] dataList = {"", "", "", ""};
        ArrayList<Citas> ListCitas = _context.CargarCitas();

        for(Citas cita: ListCitas){

            String DoctorName = _context.CargarDoctorByID(cita.getDoctorID()).toString();
            String PacienteName = _context.CargarPacienteByID(cita.getPacienteID()).toString();

            Object[] dataList = {cita.getCitaID(), cita.getMotivoCita(), DoctorName, PacienteName};

            model.addRow( dataList);
        }

        tlbListaCitas.getSelectionModel().addListSelectionListener((ListSelectionEvent event) -> {

            Citas cita = new Citas();
            cita.setCitaID(Integer.parseInt(tlbListaCitas.getValueAt(tlbListaCitas.getSelectedRow(), 0).toString()));
            this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            dispose();
            frmCitas frm = new frmCitas(cita, new frmPrincipal());
            frm.setVisible(true);
        });
    }

    private javax.swing.JButton btnAgregarCita;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tlbListaCitas;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jScrollPane1 = new javax.swing.JScrollPane();
        tlbListaCitas = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnAgregarCita = new javax.swing.JButton();

        jMenu3.setText("jMenu3");

        jMenu4.setText("jMenu4");

        jMenuItem1.setText("jMenuItem1");

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        tlbListaCitas.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        tlbListaCitas.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {

                },
                new String [] {
                        "No. Cita", "Razon", "Doctor", "Paciente"
                }
        ) {
            Class[] types = new Class [] {
                    java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                    false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tlbListaCitas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tlbListaCitas.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tlbListaCitas);

        jPanel3.setBackground(new java.awt.Color(0, 3, 207));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Listado de citas");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(358, 358, 358)
                                .addComponent(jLabel2)
                                .addContainerGap(376, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnAgregarCita.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        btnAgregarCita.setText("Generar nueva cita");
        btnAgregarCita.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarCitaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(366, 366, 366)
                                .addComponent(btnAgregarCita)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 472, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnAgregarCita, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(87, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>
}
