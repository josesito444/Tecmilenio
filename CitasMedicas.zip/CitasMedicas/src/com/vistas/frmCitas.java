package com.vistas;

import com.clases.Citas;
import com.clases.Doctores;
import com.clases.Paciente;
import com.dboperaciones.DBOperaciones;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class frmCitas extends javax.swing.JFrame {

    DBOperaciones _context;
    Object _formulario;
    Citas CitaEliminar;

    public frmCitas(Object Formulario) {
        super("Citas");
        initComponents();
        btnEliminar.setVisible(false);

        Border border = BorderFactory.createMatteBorder(2, 2, 2, 2, Color.GRAY);
        pnlFecha.setBorder(border);

        _context = new DBOperaciones();
        ConsultarPacientes();
        ConsultarDoctores();
        ValidarComboFecha();

        _formulario = Formulario;
    }

    public frmCitas(Citas Cita, Object Formulario) {
        super("Citas");
        initComponents();

        Border border = BorderFactory.createMatteBorder(2, 2, 2, 2, Color.GRAY);
        pnlFecha.setBorder(border);

        _context = new DBOperaciones();
        ConsultarPacientes();
        ConsultarDoctores();

        Cita = _context.CargarCitaByID(Cita.getCitaID());
        CargarCita(Cita);
        _formulario = Formulario;
        btnEliminar.setVisible(true);
        btnGrabarCita.setText("Actualizara Cita");
        CitaEliminar = Cita;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCitas(4).setVisible(true);
            }
        });
    }

    private void lblAddPacienteMouseEntered(java.awt.event.MouseEvent evt) {
        Border border = BorderFactory.createMatteBorder(2, 2, 2, 2, Color.GRAY);
        lblAddPaciente.setBorder(border);
    }
    private void lblAddPacienteMouseExited(java.awt.event.MouseEvent evt) {
        lblAddPaciente.setBorder(null);
    }
    private void lblAddPacienteMouseClicked(java.awt.event.MouseEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmPaciente frm = new frmPaciente(_formulario);
        frm.setVisible(true);
    }
    private void lblAddDoctorMouseEntered(java.awt.event.MouseEvent evt) {
        Border border = BorderFactory.createMatteBorder(2, 2, 2, 2, Color.GRAY);
        lblAddDoctor.setBorder(border);
    }
    private void lblAddDoctorMouseExited(java.awt.event.MouseEvent evt) {
        lblAddDoctor.setBorder(null);
    }
    private void lblAddDoctorMouseClicked(java.awt.event.MouseEvent evt) {
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        dispose();
        frmDoctor frm = new frmDoctor(_formulario);
        frm.setVisible(true);
    }
    private void btnGrabarCitaMouseClicked(java.awt.event.MouseEvent evt) {

        if(ValidarCampos()){
            try {
                ArrayList<Citas> ListCitas = _context.CargarCitas();
                int CitasID = 0;
                for(Citas cita: ListCitas){
                    if(CitasID <= cita.getCitaID()) {
                        CitasID = cita.getCitaID();
                    }
                }
                CitasID = CitasID + 1;
                Paciente paciente = (Paciente) cmbPaciente.getSelectedItem();
                Doctores doctor = (Doctores) cmbDoctor.getSelectedItem();

                String Fecha = GetFechas();

                Citas cita = new Citas();
                cita.setCitaID(CitasID);
                cita.setFechaHora(Fecha);
                cita.setMotivoCita(txtMotivo.getText());
                cita.setPacienteID(paciente.getPacienteID());
                cita.setDoctorID(doctor.getDoctorID());


                if(btnGrabarCita.getText() == "Actualizara Cita"){
                    cita.setCitaID(CitaEliminar.getCitaID());
                    if(_context.ActualizarCita(cita)){
                        JOptionPane.showMessageDialog(this, "Cita Actualizada correctamente");
                    }
                } else {
                    if(_context.GuardarCita(cita)){
                        JOptionPane.showMessageDialog(this, "Cita registrado correctamente");
                    }
                }
                switch(_formulario.getClass().getSimpleName()){
                    case "frmPrincipal": //Formulari oprincipal
                        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                        dispose();
                        frmPrincipal frm = new frmPrincipal();
                        frm.setVisible(true);
                        break;
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(frmCitas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        switch(_formulario.getClass().getSimpleName()){
            case "frmPrincipal": //Formulari oprincipal
                this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                dispose();
                frmPrincipal frm = new frmPrincipal();
                frm.setVisible(true);
                break;
        }
    }
    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {
        if(_context.EliminarCita(CitaEliminar)){
            JOptionPane.showMessageDialog(this, "Cita Actualizada correctamente");
        }
        switch(_formulario.getClass().getSimpleName()){
            case "frmPrincipal": //Formulari oprincipal
                this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                dispose();
                frmPrincipal frm = new frmPrincipal();
                frm.setVisible(true);
                break;
        }
    }

    public void ConsultarPacientes() {
        ArrayList<Paciente> ListPacientes = _context.CargarPaciente();

        ListPacientes.forEach((paciente) -> {
            cmbPaciente.addItem(paciente);
        });
    }

    public void ConsultarDoctores() {
        ArrayList<Doctores> ListDoctores = _context.CargarDoctores();

        ListDoctores.forEach((doctor) -> {
            cmbDoctor.addItem(doctor);
        });
    }

    public boolean ValidarCampos() {
        boolean continuar = true;
        Border border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red);

        if( txtMotivo.getText().equals("") ){
            txtMotivo.setBorder(border);
            return false;
        } else {
            txtMotivo.setBorder(null);
        }

        if( cmbPaciente.getSelectedItem() == null ){
            cmbPaciente.setBorder(border);
            return false;
        } else {
            cmbPaciente.setBorder(null);
        }

        if( cmbDoctor.getSelectedItem() == null ){
            cmbDoctor.setBorder(border);
            return false;
        } else {
            cmbDoctor.setBorder(null);
        }

        return continuar;
    }

    public String GetFechas(){

        String Dia = Integer.parseInt(cmbDia.getSelectedItem().toString()) < 10 ? "0" + cmbDia.getSelectedItem().toString() : cmbDia.getSelectedItem().toString();
        String Mes = Integer.parseInt(cmbMes.getSelectedItem().toString()) < 10 ? "0" + cmbMes.getSelectedItem().toString() : cmbMes.getSelectedItem().toString();
        String Anio = (String) cmbAnio.getSelectedItem();

        String Hora = Integer.parseInt(cmbHora.getSelectedItem().toString()) < 10 ? "0" + cmbHora.getSelectedItem().toString() : cmbHora.getSelectedItem().toString();
        String Minuto = Integer.parseInt(cmbMinuto.getSelectedItem().toString()) < 10 ? "0" + cmbMinuto.getSelectedItem().toString() : cmbMinuto.getSelectedItem().toString();

        String Fecha = Dia + "/" + Mes + "/" + Anio + " " + Hora + ":" + Minuto;
        return Fecha;
    }

    public void ValidarComboFecha(){
        LocalDate fecha = LocalDate.now();
        LocalTime hora = LocalTime.now();

        cmbDia.setSelectedItem(String.valueOf(fecha.getDayOfMonth()));
        cmbMes.setSelectedItem(String.valueOf(fecha.getMonthValue()));
        cmbAnio.setSelectedItem(String.valueOf(fecha.getYear()));

        String Hora = String.valueOf(hora.getHour());
        if(hora.getHour() < 10 ){
            Hora = "0" + String.valueOf(hora.getHour());
        }
        cmbHora.setSelectedItem(Hora);

        String Minuto = String.valueOf(hora.getMinute());
        if(hora.getMinute() < 10 ){
            Minuto = "0" + String.valueOf(hora.getMinute());
        }
        cmbMinuto.setSelectedItem(Minuto);
    }

    public void CargarCita(Citas CitaCargar){

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fe = CitaCargar.getFechaHora().substring(0, 10);
        LocalDate fecha = LocalDate.parse(CitaCargar.getFechaHora().substring(0, 10), formatter);

        String s = CitaCargar.getFechaHora().substring(11, 16);
        LocalTime hora = LocalTime.parse(CitaCargar.getFechaHora().substring(11, 16));

        cmbDia.setSelectedItem(String.valueOf(fecha.getDayOfMonth()));
        cmbMes.setSelectedItem(String.valueOf(fecha.getMonthValue()));
        cmbAnio.setSelectedItem(String.valueOf(fecha.getYear()));

        String Hora = String.valueOf(hora.getHour());
        if(hora.getHour() < 10 ){
            Hora = "0" + String.valueOf(hora.getHour());
        }
        cmbHora.setSelectedItem(Hora);

        String Minuto = String.valueOf(hora.getMinute());
        if(hora.getMinute() < 10 ){
            Minuto = "0" + String.valueOf(hora.getMinute());
        }
        cmbMinuto.setSelectedItem(Minuto);

        txtMotivo.setText(CitaCargar.getMotivoCita());

        Paciente paci = _context.CargarPacienteByID(CitaCargar.getPacienteID());
        cmbPaciente.getModel().setSelectedItem(paci);

        Doctores doc = _context.CargarDoctorByID(CitaCargar.getPacienteID());
        cmbDoctor.getModel().setSelectedItem(doc);

    }


    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabarCita;
    private javax.swing.JComboBox<String> cmbAnio;
    private javax.swing.JComboBox<String> cmbDia;
    private javax.swing.JComboBox<Doctores> cmbDoctor;
    private javax.swing.JComboBox<String> cmbHora;
    private javax.swing.JComboBox<String> cmbMes;
    private javax.swing.JComboBox<String> cmbMinuto;
    private javax.swing.JComboBox<Paciente> cmbPaciente;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblAddDoctor;
    private javax.swing.JLabel lblAddPaciente;
    private javax.swing.JLabel lblAño;
    private javax.swing.JLabel lblDia;
    private javax.swing.JLabel lblDoctor;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblHora;
    private javax.swing.JLabel lblMes;
    private javax.swing.JLabel lblMinuto;
    private javax.swing.JLabel lblMotivo;
    private javax.swing.JLabel lblPaciente;
    private javax.swing.JPanel pnlFecha;
    private javax.swing.JTextField txtMotivo;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        lblMotivo = new javax.swing.JLabel();
        lblPaciente = new javax.swing.JLabel();
        lblDoctor = new javax.swing.JLabel();
        pnlFecha = new javax.swing.JPanel();
        cmbDia = new javax.swing.JComboBox<>();
        lblDia = new javax.swing.JLabel();
        cmbMes = new javax.swing.JComboBox<>();
        lblMes = new javax.swing.JLabel();
        cmbAnio = new javax.swing.JComboBox<>();
        lblAño = new javax.swing.JLabel();
        cmbHora = new javax.swing.JComboBox<>();
        cmbMinuto = new javax.swing.JComboBox<>();
        lblHora = new javax.swing.JLabel();
        lblMinuto = new javax.swing.JLabel();
        txtMotivo = new javax.swing.JTextField();
        cmbPaciente = new javax.swing.JComboBox<>();
        cmbDoctor = new javax.swing.JComboBox<>();
        btnGrabarCita = new javax.swing.JButton();
        lblAddPaciente = new javax.swing.JLabel();
        lblAddDoctor = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 3, 207));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Registro de Citas");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(jLabel2)
                                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblFecha.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblFecha.setText("Fecha");

        lblMotivo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblMotivo.setText("Motivo");

        lblPaciente.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblPaciente.setText("Paciente");

        lblDoctor.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblDoctor.setText("Doctor");

        cmbDia.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cmbDia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        lblDia.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblDia.setText("Día");

        cmbMes.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cmbMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

        lblMes.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblMes.setText("Mes");

        cmbAnio.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cmbAnio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "2036", "2037", "2038", "2039" }));

        lblAño.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblAño.setText("Año");

        cmbHora.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cmbHora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", " " }));

        cmbMinuto.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        cmbMinuto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        lblHora.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblHora.setText("Hora");

        lblMinuto.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblMinuto.setText("Minuto");

        javax.swing.GroupLayout pnlFechaLayout = new javax.swing.GroupLayout(pnlFecha);
        pnlFecha.setLayout(pnlFechaLayout);
        pnlFechaLayout.setHorizontalGroup(
                pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnlFechaLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblDia)
                                        .addComponent(lblMes)
                                        .addComponent(lblAño))
                                .addGap(26, 26, 26)
                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cmbAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(pnlFechaLayout.createSequentialGroup()
                                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(cmbMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(56, 56, 56)
                                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addGroup(pnlFechaLayout.createSequentialGroup()
                                                                .addComponent(lblMinuto)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(cmbMinuto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(pnlFechaLayout.createSequentialGroup()
                                                                .addComponent(lblHora)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(cmbHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlFechaLayout.setVerticalGroup(
                pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnlFechaLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblDia)
                                        .addComponent(lblHora)
                                        .addComponent(cmbHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(cmbMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblMes)
                                        .addComponent(lblMinuto)
                                        .addComponent(cmbMinuto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pnlFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(cmbAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblAño))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtMotivo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        cmbPaciente.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        cmbDoctor.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        btnGrabarCita.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGrabarCita.setText("Grabar Cita");
        btnGrabarCita.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGrabarCitaMouseClicked(evt);
            }
        });

        lblAddPaciente.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblAddPaciente.setText(" +");
        lblAddPaciente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAddPacienteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAddPacienteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAddPacienteMouseExited(evt);
            }
        });

        lblAddDoctor.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblAddDoctor.setText(" +");
        lblAddDoctor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAddDoctorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAddDoctorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAddDoctorMouseExited(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar Cita");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(28, 28, 28)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(lblPaciente)
                                                        .addComponent(lblDoctor))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(cmbPaciente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(cmbDoctor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(lblAddPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(lblAddDoctor, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(25, 25, 25)
                                                                .addComponent(lblMotivo)
                                                                .addGap(32, 32, 32)
                                                                .addComponent(txtMotivo, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(43, 43, 43)
                                                                .addComponent(pnlFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(142, 142, 142)
                                                                .addComponent(lblFecha))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(67, 67, 67)
                                                                .addComponent(btnGrabarCita)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnEliminar)))
                                                .addGap(0, 0, Short.MAX_VALUE)))
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblFecha)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(pnlFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblMotivo)
                                        .addComponent(txtMotivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblPaciente)
                                        .addComponent(cmbPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblAddPaciente))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblDoctor)
                                        .addComponent(cmbDoctor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblAddDoctor))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btnGrabarCita, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                                        .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap(35, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>
}
